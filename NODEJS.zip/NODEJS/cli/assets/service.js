const <%= name %>Service = {
  doGetResource: async (requestBody) => {}
};

module.exports = <%= name %>Service;
