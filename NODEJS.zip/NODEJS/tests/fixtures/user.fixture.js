module.exports = {
  id: '5a406953-755c-44c4-940e-0fec7348a8a3',
  phone: '9934897867',
  password: 'jklsf0928304',
  role: 'User'
}