const Config = require('./config');
const Routes = require('./routes');

module.exports = {
  Config,
  Routes
};
