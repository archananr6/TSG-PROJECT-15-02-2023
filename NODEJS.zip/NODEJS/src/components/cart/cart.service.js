const { result } = require('lodash');
const decodeToken = require('../../middlewares/auth');
const db = require('../../db/db.js');
const logger = require('../../support/logger');
const { BadRequestError, NotFoundError } = require('../../utils/api-errors');
const { verifyJWT } = require('../Auth/jwt.service');

const CartService = {
  /**
   * Login a user and generate token.
   * @async
   * @method
   * @param {UserDto} requestBody - Request Body
   * @returns {Context} Context object
   * @throws {NotFoundError} When the user is not found.
   */

  //addtocartitems
  addCartItems: async (requestBody, headers) => {
    try {
      const token = headers.Authorization.replace('Bearer ', ''); //replace bearer
      const email = await verifyJWT({ token }) //decode token
        .then((result) => {
          console.log(result);
          return result.email;
        });

      // Query user_id from user_account using email
      const queryObj = `SELECT user_id from user_account where email='${email}'`;
      const resultQuery = await db.promise(queryObj);
      console.log(resultQuery);
      // Get product id from request body
      const { products_id } = requestBody;
      console.log('addtocartitems1');
      // Get user id from resultQuery
      const user_id1 = resultQuery[0].user_id;
      // Insert the cart item into cart table
      var sqlObj = `INSERT INTO cart VALUES (?,?,?)`;
      const resultObj = await db.promise(sqlObj, [, user_id1, products_id]);
      console.log('resultObj', JSON.stringify(resultObj));
      console.log('addtocartitems2');
      // Check if insertion was successful and throw error if not
      if (resultObj.length == 0) {
        // Log error
        logger.error('addCartItems()' + error);
        // Throw error
        throw new BadRequestError('Insert failed');
      }
      return {
        resultObj
      };
    } catch (error) {
      // Log error and rethrow it
      logger.error(`addCartItems() failed: ${error}`);
      throw error;
    }
  },

  //View cart items
  viewCartItems: async (requestBody, headers) => {
    try {
        // Extract the JWT token from the Authorization header
      const token = headers.Authorization.replace('Bearer ', ''); //replace bearer
        // Decode the token to get the user's email
      const email = await verifyJWT({ token }) //decode token
        .then((result) => {
          return result.email;
        });
        // Query the database to get the user ID associated with the email
      const queryObj = `SELECT user_id from user_account where email='${email}'`;
      const resultQuery = await db.promise(queryObj);
      const user_id1 = resultQuery[0].user_id;
      // Query the database to get the products in the user's cart
      var sqlObj = `select * from product join cart on cart.products_id=product.product_id where user_id1='${user_id1}'`;
      const queryResult = await db.promise(sqlObj);
      console.log(queryResult);
      return {
        queryResult
      };
    } catch (error) {
        // If an error occurs, log it and re-throw it
      logger.error(`viewCartItems() failed: ${error}`);
      throw error;
    }
  },

  // delete Cart Items
  deleteCartItems: async (params, headers) => {
    try {
       // Create a SQL query to delete the cart item with the specified cart_id
      var sqlObj = `DELETE FROM cart WHERE cart_id = '${params.cart_id}'`;
      console.log(sqlObj);
        // Execute the query using a database connection from the `db` object
      const queryResult = await db.promise(sqlObj);
       // Return the results in an object
      return {
        queryResult
      };
    } catch (error) {
         // If an error occurs, log it and re-throw it
      logger.error(`deleteCartItems() failed: ${error}`);
      throw error;
    }
  }
};

module.exports = CartService;
