const bcrypt = require('bcryptjs');
const { User } = require('../../db/models');
const JwtService = require('./jwt.service');
const db = require('../../db/db.js');
const { BadRequestError, NotFoundError } = require('../../utils/api-errors');
const logger = require('../../support/logger');

const AuthService = {
  /**
   * Login a user and generate token.
   * @async
   * @method
   * @param {UserDto} requestBody - Request Body
   * @returns {Context} Context object
   * @throws {NotFoundError} When the user is not found.
   */

  // Login method
  doLogin: async (requestBody) => {
    try {
      const { email, password } = requestBody;

      // Query the database to select user by email
      let queryObj = `SELECT user_account.user_id,user_account.email,user_account.name,user_account.password,role.role_name as role
        FROM user_account
        JOIN role ON user_account.roleId = role.role_id where user_account.email= '${email}';`;

      const resultObj = await db.promise(queryObj);

      if (resultObj.length == 0) {
        throw new BadRequestError('Username or Password is invalid!');
      }

      const passwordMatch = await bcrypt.compare(password, resultObj[0].password);

      if (!passwordMatch) {
        throw new BadRequestError('Password is invalid!');
      }

      // Construct the payload and generate the JWT token
      const payload = {
        user_id: resultObj[0].user_id,
        role: resultObj[0].role,
        email: resultObj[0].email,
        user: resultObj[0].name,
      };

      const accessToken = await JwtService.generateJWT({
        payload
      });

      // Return the access token and payload
      return {
        accessToken,
        ...payload
      };
    } catch (error) {
      // Log the error and re-throw the exception
      logger.error('doLogin() - Error: ', error);
      throw error;
    }
  },

  // Register method
  doRegister: async (requestBody) => {
    try {
      const { name, email, password } = requestBody;

      // Query the database to check if the email is already in use
      let sqlQuery = `SELECT email from user_account where email = '${email}'`;
      const emailResult = await db.promise(sqlQuery);

      if (!emailResult.length == 0) {
        throw new BadRequestError('Email is already in use');
      }

      // Query the database to get the role ID for 'user'
      let queryObj = `select role_id from role where role_name = 'user'`;
      const roleResult = await db.promise(queryObj);

      // Insert the user into the database with the 'user' role ID
      let sqlObj = `INSERT INTO user_account VALUES (?,?,?,?,?)`;

      const resultObj = await db
        .promise(sqlObj, [, name, email, bcrypt.hashSync(password),roleResult[0].role_id])
        .then((result) => {
          return result;
        })
        .catch((err) => {
          throw err;
        });

      if (resultObj.length == 0) {
        throw new BadRequestError('Insert failed');
      }

      // Return a success message
      return {
        message: 'Registered successfully'
      };
    } catch (error) {
      // Log the error and re-throw the exception
      logger.error('doRegister() - Error: ', error);
      throw error;
    }
  }
};

module.exports = AuthService;
