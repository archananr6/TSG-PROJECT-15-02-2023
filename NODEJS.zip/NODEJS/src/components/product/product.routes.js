/**
 *
 * @param {Object} ProductRouter
 * @param {ExpressRouter} ProductRouter.router
 * @param {ProductController} ProductRouter.ProductController
 * @param {ProductValidator} AuthRouter.ProductValidator
 * @param {makeExpressCallback} ProductRouter.makeExpressCallback
 * @param {makeValidatorCallback} ProductRouter.makeValidatorCallback
 * @returns {ExpressRouter}
 */
 const authorization = require('../../middlewares/auth');
 module.exports = ({ router, ProductController, ProductValidator, makeValidatorCallback, makeExpressCallback }) => {
    router.get('/listproducts',authorization, makeExpressCallback(ProductController.listproduct));
    router.post('/addproducts',authorization, makeExpressCallback(ProductController.addproduct));
    router.delete('/deleteproduct/:product_id',authorization, makeExpressCallback(ProductController.deleteproduct));
    
    
  
    return router;
  };