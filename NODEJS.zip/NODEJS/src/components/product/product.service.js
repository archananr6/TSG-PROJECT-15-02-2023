const db = require('../../db/db.js');
const { BadRequestError, NotFoundError } = require('../../utils/api-errors');
const logger =require('../../support/logger');
const { query } = require('express');

const ProductService = {
  /**
   * Login a user and generate token.
   * @async
   * @method
   * @param {UserDto} requestBody - Request Body
   * @returns {Context} Context object
   * @throws {NotFoundError} When the user is not found.
   */

  //getProductList  Api
  getProductList: async (requestBody) => {
    try {
      var queryObj = `select * from product`;
      const resultObj = await db.promise(queryObj);
      return resultObj;
    } catch (error) {
      logger.error('getProductList()' + error);
    }
  },

  //AddProduct
  addProductList: async (requestBody) => {
    try {
      const { product_name, product_description, product_price, product_image, category_name, inventory_id1 } =
        requestBody;
      //Create a SQL query to check if the product name already exists in the database
      const sqlProductName = `select product_name from product where product_name = '${product_name}'`;
      const resultProduct = await db.promise(sqlProductName);
      // If the query returns a non-empty result, the product already exists, so throw an error
      if (!resultProduct.length == 0) {
        return new BadRequestError('Product is already exists');
      }
      // Create a SQL query to get the category ID for the specified category name
      const sqlCategory = `SELECT category_id from category where category_name = '${category_name}';`;
      const resultCategory = await db.promise(sqlCategory);
      // Create a SQL query to insert the new product into the database
      const sqlQuery = `INSERT INTO product VALUES (?,?,?,?,?,?,?)`;
      // Execute the query using a database connection from the `db` object and pass in the product properties as parameters
      const queryResult = await db
        .promise(sqlQuery, [
          ,
          product_name,
          product_description,
          product_price,
          product_image,
          resultCategory[0].category_id,
          1
        ])
        .then((result) => {
          return result;
        });
      return queryResult;
    } catch (error) {
      // If an error occurs, log it and re-throw it
      logger.error(`addProductList() failed: ${error}`);
      throw error;
    }
  },

  //DeleteProduct
  deleteProductList: async (params) => {
    try {
      // Construct the SQL query to delete a product by ID
      const queryDelete = `DELETE FROM product where product_id = ${params.product_id}`;
      // Execute the delete query using the database connection
      const deleteResult = await db.promise(queryDelete);
      // Return the result of the delete operation
      return deleteResult;
    } catch (error) {
      // If an error occurs, log the error and re-throw it
      logger.error(`deleteProductList() failed: ${error}`);
      throw error;
    }
  }
};



 
module.exports = ProductService;