'use strict';

module.exports = {
  singleQuote: true,
  trailingComma: 'none',
  bracketSpacing: true,
  jsxBracketSameLine: false,
  printWidth: 120,
  tabWidth: 2,
  useTabs: false,
  semi: true,
  parser: 'flow'
};
