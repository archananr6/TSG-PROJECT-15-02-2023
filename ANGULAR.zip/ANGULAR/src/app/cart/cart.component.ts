import { Component, OnInit } from '@angular/core';
import { response } from 'express';
import { Logger, MessageService, UntilDestroy, untilDestroyed } from '@shared';
import { request } from 'http';
import { CartService } from './cart.service';





@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss'],
})
export class CartComponent implements OnInit {
  isLoading:boolean = false;
  constructor(private _cartService:CartService,private messageService: MessageService) {}
  cartList:any = [];
  ngOnInit(): void {
   this.viewCartList();
   this.messageService.sendMessage('added successfully'); 
  }
  //viewCartList
  viewCartList(){
    this._cartService.viewCartItems().subscribe(response=>{
      this.cartList=response.data.queryResult
    })
  }

  //delete cart product
  deleteCart(cart_id:any){
    this.isLoading = true; 
    this._cartService.deleteCartItem(cart_id).subscribe(
      (response)=>{
       
        this.isLoading = false;
        this.cartList = response.data;
        this.viewCartList();
        this.messageService.sendMessage('added successfully'); 
      }
    )
  }
  
}
