import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { marker } from '@biesbjerg/ngx-translate-extract-marker';

import { AdminproductComponent } from './adminproduct.component';
import { Shell } from '@app/shell/shell.service';
import { AuthenticationGuard } from '@app/auth';
import { AuthenticationroleGuard } from '@app/auth/authenticationrole.guard';


const routes: Routes = [{ path: 'adminproduct',canActivate:[AuthenticationGuard,AuthenticationroleGuard],component:AdminproductComponent, data: { title: marker('AdminProduct') } },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AdminproductRoutingModule {}
