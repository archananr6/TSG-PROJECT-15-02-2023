import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }

  getProductList(): Observable<any> {
    // Send an HTTP GET request to the API endpoint
    return this.http.get('/product/listproducts');
  }

  deleteProductList(productid:any): Observable<any> {
    return this.http.delete(`/product/deleteproduct/${productid}`);
    
  }
}
