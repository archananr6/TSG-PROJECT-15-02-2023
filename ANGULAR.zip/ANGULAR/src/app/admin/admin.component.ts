import { Component, OnInit, ViewChild } from '@angular/core';
import { CellClickedEvent, ColDef, GridReadyEvent } from 'ag-grid';
import { AgGridAngular } from 'ag-grid-angular';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { AdminService } from './admin.service';
import { ButtonRendererComponent } from './button-renderer.component';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
})
export class AdminComponent implements OnInit {
  rowData: any;
  isLoading: boolean = false;
  frameworkComponents: any;
  credentialsService: any;
  constructor(private adminService: AdminService, private _toasterService: ToastrService) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponent,
    }
  }
  productList: any;
  public rowData$!: Observable<any[]>;
  @ViewChild(AgGridAngular) agGrid!: AgGridAngular;
  ngOnInit(): void {
    this.getProductList();
  }
  onCellClicked(e: CellClickedEvent): void {
    console.log('cellClicked', e);
  }
  
  onGridReady(params: GridReadyEvent) {
    // this.rowData$ = this._tasklistService.getTasklist();
  }

  clearSelection(): void {
    this.agGrid.api.deselectAll();
  }

  columnDefs = [
    { headerName: 'ID', field: 'product_id' },
    { headerName: 'Product Name', field: 'product_name', filter: true, floatingFilter: true },
    { headerName: 'Product Description', field: 'product_description', filter: true, floatingFilter: true },
    { headerName: 'Project Image url', field: 'product_image', filter: true, floatingFilter: true },
    { headerName: 'Price', field: 'product_price', filter: true, floatingFilter: true },
    { headerName: 'Delete', field:'button',cellRenderer: 'buttonRenderer',
    cellRendererParams: {
      onClick: this.deleteProduct.bind(this),
      label: 'Delete'
    },},
    { headerName: 'Edit', field:'button',cellRenderer: 'buttonRenderer',
    cellRendererParams: {
      onClick: this.editProduct.bind(this),
      label: 'Edit'
    },}
  ];
  //getProductList
  getProductList() {
    this.adminService.getProductList().subscribe((res) => {
      this.productList = res.data;
      this.rowData=res.data;
    });
  }
  //delete product
  deleteProduct(row: any) {
    this.isLoading = true;
    this.adminService.deleteProductList(row.rowData.product_id).subscribe((response) => {
      this.isLoading = false;
      this._toasterService.success('Deleted Product Successfully');
      this.productList = response.data;
      this.getProductList();
    });
  }
  editProduct(e:any){

  }
  onBtnClick1(e:any) {
   
  }
  logout(){
    sessionStorage.clear();
    location.reload();
  }
 
}
