import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { marker } from '@biesbjerg/ngx-translate-extract-marker';
import { AuthenticationGuard } from '@app/auth';
import { AdminComponent } from './admin.component';
import { AuthenticationroleGuard } from '@app/auth/authenticationrole.guard';

const routes: Routes = [{ path: 'admin',canActivate:[AuthenticationGuard,AuthenticationroleGuard],component:AdminComponent, data: { title: marker('Admin') } },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})
export class AdminRoutingModule {}
