import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Logger, MessageService } from '@shared';
import { AuthenticationService, CredentialsService } from '@app/auth';
import { Subscription } from 'rxjs';
import { CartService } from '@app/cart/cart.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  menuHidden = true;
  isLoggedIn!:any;
  isVibrating = false;
  userName:string ='';
  cartCount:number=0;
  subscription: Subscription;
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private credentialsService: CredentialsService,
    private messageService: MessageService,
    private _cartService:CartService
  ) {

    this.subscription = this.messageService.getMessage().subscribe(message => {
      if (message) {
        this._cartService.viewCartItems().subscribe(response=>{
          this.cartCount= response.data.queryResult.length;
        });
      }else{
        console.log("message",message);
      }
    });
  }

  ngOnInit() {
    
    this.userName = this.credentialsService.getUserName()
  }

  toggleMenu() {
    this.menuHidden = !this.menuHidden;
  }

  logout() {
    this.authenticationService.logout().subscribe(() => this.router.navigate(['/login'], { replaceUrl: true }));
  }

  get username(): string | null {
    const credentials = this.credentialsService.credentials;
    return credentials ? credentials.username : null;
  }
  vibrateIcon() {
    this.isVibrating = true;
    setTimeout(() => {
      this.isVibrating = false;
    }, 500);
  }
}
