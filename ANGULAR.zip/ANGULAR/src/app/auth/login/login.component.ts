import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { finalize } from 'rxjs/operators';

import { environment } from '@env/environment';
import { Logger, UntilDestroy, untilDestroyed } from '@shared';
import { AuthenticationService } from '../authentication.service';
import { CredentialsService } from '@app/auth';
import { ToastrService } from 'ngx-toastr';

const log = new Logger('Login');

@UntilDestroy()
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  errorObj!: boolean | false;
  loginError: boolean = false;
  isLoading: boolean = false;
  loginForm!: FormGroup;
  constructor(
    private _router: Router,
    private _activatedRouter: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private _formBuilder :FormBuilder,
    private _credentialService :CredentialsService,
    private  _toasterService :ToastrService
  ) {
    this.createForm();
  }

  ngOnInit() {
  }


  login(){
  try {
    if 
    (this.loginForm.valid) { 
      this.isLoading = true;
      this.authenticationService.login(this.loginForm.value).subscribe(
      (response) => { 
      this.isLoading = false;   
      this._credentialService.setCredentials(response)
      if(response.data.role === 'user')
      {
        this._toasterService.success("Login Success")
        this._router.navigate(['/home']);
      }
      else if(response.data.role==='admin'){
        this._router.navigate(['/admin']);
      }
    },
    (error) => {
      this.isLoading = false;
      this.errorObj = true
      log.error('login() funtion ', error);
    } );
  }
} 
catch (error) {
  log.error('login() funtion ', error);
}
 };
  private createForm() {
    this.loginForm = this._formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]

    });
  }
}
