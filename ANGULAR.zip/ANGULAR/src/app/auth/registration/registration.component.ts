import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { finalize } from 'rxjs/operators';
import * as bcrypt from 'bcryptjs';
import { environment } from '@env/environment';
import { Logger, UntilDestroy, untilDestroyed } from '@shared';
import { AuthenticationService } from '../authentication.service';
import { CredentialsService } from '@app/auth';
import * as console from 'console';
import { ToastrService } from 'ngx-toastr';



const log = new Logger('RegisterUser');

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss'],
})
export class RegistrationComponent {
  error: string | undefined;
  registerForm!: FormGroup;
  isLoading = false;
  errorObj:boolean=false;
  errorText:any;
  constructor(
    private _router: Router,
    private _activatedRouter: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private _formBuilder :FormBuilder,
    private _credentialService :CredentialsService,
    private  _toasterService :ToastrService
 
  ) {
    this.createForm();
  }


  registerUser(){
    if(this.registerForm.valid ){

      // const salt = bcrypt.genSaltSync(10);
      // const hasedPassword = bcrypt.hashSync(this.registerForm.value.password,salt);
      // console.log(hasedPassword);
      this.isLoading = true;
      try {
        // const requestObj={
        //   name: this.registerForm.value.name,
        //   email: this.registerForm.value.email,
        //   password: hasedPassword
        // }
        this.authenticationService.register(this.registerForm.value).subscribe(
          (response) => { 
            if(response.data.status==400){
            this._toasterService.error("Email is already registered");
              
            }
            else{
            log.info(response);
            this.isLoading = false;
            this._toasterService.success("Email registered successfully")
            this._router.navigate(['/login']);
          }
        },
          (error) => {
            this.isLoading = false;
            this.errorObj = true;
            this.errorText = error?.error?.message;
            log.error('registerUser() funtion ', error);
          } );
      } catch (error) {
        this.isLoading = false;
        log.error('error occured', error);
      }
    }
  }


  private createForm() {
    this.registerForm = this._formBuilder.group({
      name:['',Validators.required],
      email: ['', Validators.pattern(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)],
      password: ['', Validators.required]

    });
  }
}

